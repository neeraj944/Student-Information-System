
import tkinter as tk
from tkinter import messagebox
import csv
import os

CSV_FILE = 'students.csv'

def load_students():
    if not os.path.isfile(CSV_FILE):
        return []
    with open(CSV_FILE, 'r') as file:
        reader = csv.reader(file)
        return list(reader)[1:]  # Skip header

def save_students(students):
    with open(CSV_FILE, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([
            "Name", "Age", "Gender", "Course", "Contact", "Email",
            "Joining Year", "Ending Year", "Attendance (%)", "Grade", "Performance"
        ])
        writer.writerows(students)

def add_student():
    values = [entry.get().strip() for entry in entries.values()]

    if not all(values):
        messagebox.showwarning("Input Error", "Please fill all fields.")
        return

    name, age, gender, course, contact, email, joining, ending, attendance, grade, performance = values

    if not (age.isdigit() and contact.isdigit() and joining.isdigit() and ending.isdigit()):
        messagebox.showwarning("Input Error", "Age, Contact, Joining and Ending Year must be numeric.")
        return

    try:
        float(attendance)
    except ValueError:
        messagebox.showwarning("Input Error", "Attendance must be a number.")
        return

    if "@" not in email or "." not in email:
        messagebox.showwarning("Input Error", "Enter a valid email address.")
        return

    students = load_students()
    students.append(values)
    save_students(students)
    messagebox.showinfo("Success", f"Student {name} added.")
    clear_entries()

def update_student():
    name = entry_name.get().strip()
    if not name:
        messagebox.showwarning("Input Error", "Enter the student name to update.")
        return

    students = load_students()
    updated = False
    for i, student in enumerate(students):
        if student[0] == name:
            students[i] = [entry.get().strip() for entry in entries.values()]
            updated = True
            break

    if updated:
        save_students(students)
        messagebox.showinfo("Updated", f"Details for {name} updated.")
    else:
        messagebox.showerror("Not Found", f"No student named {name} found.")
    clear_entries()

def delete_student():
    name = entry_name.get().strip()
    if not name:
        messagebox.showwarning("Input Error", "Enter the student name to delete.")
        return

    students = load_students()
    new_students = [s for s in students if s[0] != name]

    if len(new_students) == len(students):
        messagebox.showerror("Not Found", f"No student named {name} found.")
        return

    save_students(new_students)
    messagebox.showinfo("Deleted", f"Student {name} deleted.")
    clear_entries()

def view_students():
    students = load_students()
    if not students:
        messagebox.showinfo("No Data", "No student data available.")
        return

    win = tk.Toplevel(root)
    win.title("Student Records")
    listbox = tk.Listbox(win, width=180, height=20, font=("Courier New", 9))
    listbox.pack(padx=10, pady=10)

    header = f"{'Name':<15}{'Age':<5}{'Gender':<8}{'Course':<12}{'Contact':<12}{'Email':<25}{'Join':<6}{'End':<6}{'Attend%':<9}{'Grade':<7}{'Performance':<15}"
    listbox.insert(tk.END, header)
    listbox.insert(tk.END, "-" * 160)

    for s in students:
        row = f"{s[0]:<15}{s[1]:<5}{s[2]:<8}{s[3]:<12}{s[4]:<12}{s[5]:<25}{s[6]:<6}{s[7]:<6}{s[8]:<9}{s[9]:<7}{s[10]:<15}"
        listbox.insert(tk.END, row)

def clear_entries():
    for entry in entries.values():
        entry.delete(0, tk.END)

# GUI
root = tk.Tk()
root.title("Student Information System")
root.geometry("750x600")

fields = [
    ("Name", "entry_name"),
    ("Age", "entry_age"),
    ("Gender", "entry_gender"),
    ("Course", "entry_course"),
    ("Contact", "entry_contact"),
    ("Email", "entry_email"),
    ("Joining Year", "entry_joining"),
    ("Ending Year", "entry_ending"),
    ("Attendance (%)", "entry_attendance"),
    ("Grade", "entry_grade"),
    ("Performance", "entry_performance")
]

entries = {}

for i, (label, key) in enumerate(fields):
    tk.Label(root, text=label).grid(row=i, column=0, padx=10, pady=5, sticky="w")
    entry = tk.Entry(root, width=40)
    entry.grid(row=i, column=1, padx=10, pady=5)
    entries[key] = entry

# Assigning individual entry variables for easy access
entry_name = entries["entry_name"]
entry_age = entries["entry_age"]
entry_gender = entries["entry_gender"]
entry_course = entries["entry_course"]
entry_contact = entries["entry_contact"]
entry_email = entries["entry_email"]
entry_joining = entries["entry_joining"]
entry_ending = entries["entry_ending"]
entry_attendance = entries["entry_attendance"]
entry_grade = entries["entry_grade"]
entry_performance = entries["entry_performance"]

# Buttons
tk.Button(root, text="Add", width=18, command=add_student).grid(row=len(fields), column=0, pady=10)
tk.Button(root, text="Update", width=18, command=update_student).grid(row=len(fields), column=1, pady=10)
tk.Button(root, text="Delete", width=18, command=delete_student).grid(row=len(fields)+1, column=0, pady=10)
tk.Button(root, text="View All", width=18, command=view_students).grid(row=len(fields)+1, column=1, pady=10)

root.mainloop()
